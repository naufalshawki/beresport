<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <?php if(session()->has('success')): ?>
    <div class="alert" style="position:absolute;
      top:0;
      margin-left: 40%;
      z-index: 1000;
      padding: 20px auto;
      background-color: green;
      color: white;">
     <span class="closebtn" style="
     margin-left: 15px;
     color: white;
     font-weight: bold;
     float: right;
     font-size: 22px;
     line-height: 20px;
     cursor: pointer;
     transition: 0.3s;
     color: black;
    " onclick="this.parentElement.style.display='none';">&times;</span>
     <strong>Success!</strong>
          <?php echo e(session()->get('success')); ?>

        </div>
        <?php endif; ?>
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
      </li>
    </ul>

    

    <!-- Right navbar links -->
    <?php $__currentLoopData = $profil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profil1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <ul class="navbar-nav ml-auto">
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <p> <?php echo e($profil1->nama); ?>

              <span class="ml-2">
                <img src="<?php echo e(url('admin/dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image" style="max-width:30px">
              </span>
          </p>
        </a>
        <div class="dropdown-menu dropdown-menu-md dropdown-menu-right">
          <span class="dropdown-header">Have a nice day! <?php echo e($profil1->nama); ?> :)</span>
          
          <div class="dropdown-divider"></div>
        <a href="<?php echo e(url('admin/logout')); ?>" class="dropdown-item">
            <i class="fas fa-sign-out-alt mr-2"></i> Logout
          </a>
        </div>
      </li>
      
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </nav>
<?php /**PATH C:\xampp\htdocs\beresport\resources\views/admin/layouts/partials/navbar.blade.php ENDPATH**/ ?>