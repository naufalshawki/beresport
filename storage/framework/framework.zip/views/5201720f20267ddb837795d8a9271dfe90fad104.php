<p>Click Link in the Description to Verify Your Email</p>
<a href="<?php echo e($link); ?>">Verify Here</a>
<p>Thank you.</p>
<?php /**PATH C:\xampp\htdocs\beresport\resources\views/email/signup.blade.php ENDPATH**/ ?>